# Postman <> Interceptor Bridge

## Installation Guide

- Open `install_host` to install the Native Messaging host for Interceptor <> Postman App Integration. 

- This script adds a manifest file (com.postman.postmanapp.json) at this location `~/Library/Application Support/Google/Chrome/NativeMessagingHosts/`. Learn [more](https://developers.chrome.com/apps/nativeMessaging).

- Once installed, you'll need to restart Chrome for the changes to take effect
